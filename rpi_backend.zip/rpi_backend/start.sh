#!/bin/bash
echo "=== CopraWatch RPI Backend ==="
echo ""
echo "Installing dependencies..."
pip3 install -r requirements.txt --break-system-packages

echo ""
echo "Starting API server on port 5000..."
python3 api_server.py
