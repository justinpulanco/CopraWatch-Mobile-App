#!/usr/bin/env python3
"""
Test script for MAX6675 and SHT30 sensors
"""
from sensors import SensorManager
import time

print("\n=== CopraWatch Sensor Test ===\n")

manager = SensorManager()

try:
    print("Reading sensors every 2 seconds... (Ctrl+C to stop)\n")
    
    while True:
        data = manager.get_environmental_data()
        
        print(f"Temperature: {data['temperature']}°C")
        print(f"Humidity:    {data['humidity']}%")
        print(f"Status:      {data['status']}")
        print(f"Time:        {data['timestamp']}")
        print("-" * 40)
        
        time.sleep(2)

except KeyboardInterrupt:
    print("\n\nTest stopped by user")
    manager.cleanup()
    print("Done!")
